# PaperPocket product plan

Updated for the 1.4.0 beta. The owner has chosen to improve the free app first.
Monetization is a later decision. The eventual goal is **US$10,000 total
earnings**, not monthly revenue or a download target. No purchases, ads,
paywall, payment SDK, or publisher analytics have been added.

## Current beta: finish the document workflow

The product promise is straightforward: scan or import, arrange pages, create
a readable PDF at a sensible size, view it, and share it. Preserve original
files when compressing or extracting pages. Make cancellation understandable
and deleting a document reversible. Keep the initial screen simple.

Version 1.2 adds cancellation/page progress, persistent PDF Trash/Restore,
lossless merge and selected-page extraction for supported PaperPocket PDFs,
and optional bundled on-device Latin text recognition. These are beta features
to validate on phones. Text recognition returns editable/copyable text; it does
not add a searchable layer to a PDF or promise Urdu/handwriting recognition.

Version 1.3 adds background normal/ID-card PDF creation with progress,
cancellation and optional notifications, folders/Favorites, and front/back
ID-card copies on one A4 page. Keep Home simple and these additions free.
Background completion does not yet cover import, compression, merge/extraction,
or OCR, and interrupted conversions do not restart after force-stop/reboot.

Version 1.4 adds intent-based compression presets, actual before/after byte
comparison and a full-page unsaved preview before Save smaller copy or Discard.
Only strictly smaller results are saved, with originals retained. Keep this free.
The owner approved a new signing epoch for this early beta; older installations
need export/uninstall/fresh install. Retain a verified durable private backup of
the 1.4 key before publishing, then use that key consistently for later updates.

The reported installer screenshot identifies an unfamiliar developer warning.
Its classification is recorded in [TESTING_AND_SECURITY.md](TESTING_AND_SECURITY.md).
The owner has paused warning investigation to focus on the app; no Google
clearance is claimed. Play Store publication stays on hold for now.

## Test with people before expanding scope

Start with the owner and a few volunteer testers. Expand only when feedback
justifies it; no large customer rollout is assumed. Include
Android 8 and a recent Android version, at least three phone brands, a modest
RAM/storage device, enlarged fonts, and a device where Google's scanner is
unavailable. This is a proposed test sample, not a report of completed testing.

For each tester record version, phone/Android version, task completed or failed,
reason, time to first PDF, page count, file size/profile, readability, and whether
they choose to use the app again the next week. Ask users to report these facts;
do not collect their documents or install tracking without a separate decision
and updated disclosures. Use the GitHub phone-feedback form.

Before considering a store launch, require no known document-loss defect and
successful import/scan, background convert/cancel, ID-card layout,
folders/Favorites, trash/restore, view, share/export, and restart checks across
that test sample. Review any recurring failure before adding more features. Compare the same four-page sample in Balanced, Compact,
and High. A small PDF is useful only if its text is still readable.

Next improvements should follow observed problems: lighting/blur feedback,
undo for draft-page removal, background processing for the remaining long
operations, faster large-draft page ordering, and a simpler onboarding flow.
Later, evaluate searchable PDFs, additional text scripts, annotations, and
general PDF import. Keep each iteration small enough to verify and roll back
through Git history; preserve previous stable tags and versioned downloads.

## Earning later

Keep the present promised workflow free while reviewing usage and feedback.
After users return regularly, ask which additional capability they value enough
to pay for. Evaluate a one-time Pro upgrade before assuming a subscription is
appropriate for an offline utility. Subscription pricing would need sustained
additional value. Neither a price nor a paid feature set has been chosen.

Track cumulative customer receipts, refunds, store fees, currency conversion,
taxes, development/hosting/support costs, and actual payouts separately. Gross
sales are not take-home profit. Illustrative arithmetic: 2,000 purchases at
US$5 produce US$10,000 gross. At an assumed 15% store fee they leave US$8,500
before taxes, refunds, conversion, and costs. The actual fee depends on region,
billing/program enrollment, and the rules in effect when selling; this example
is not a forecast or a current pricing proposal.

Do not spend on advertising until users retain the app and a paid offering has
been validated. Organic demonstrations and the owner's video can show real
scan quality, file-size tradeoffs, and the privacy model when the beta is ready.

## Distribution and country

Google currently lists both Indonesia and Pakistan as supporting Play developer
and merchant registration. Registration and payout setup still require correct
identity, legal address, supported payment/bank details, and tax information.
Citizenship and a temporary location do not by themselves choose an account's
legal country. Worldwide customer reach and USD goal tracking are separate
from the payout currency and taxes. Do not register under an invented country
or assume a USD price is the right local price everywhere.

Official references: [supported locations](https://support.google.com/googleplay/android-developer/answer/9306917),
[service fees](https://support.google.com/googleplay/android-developer/answer/112622),
and [15% tier enrollment](https://support.google.com/googleplay/android-developer/answer/10632485).
Recheck them before implementing billing or opening a payments profile.

The public website at https://paperpocket.sm-ali.chatgpt.site provides downloads,
privacy, help and feedback draft links. Browser PDF tools remain future work. A
native iOS edition requires its own implementation, Apple signing and iPhone
testing; it is not part of this beta.
